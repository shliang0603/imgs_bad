# coding=utf-8
"""
Copyright (c) 2018-2022. All Rights Reserved.

@author: shliang
@email: shliang0603@gmail.com
"""

import os
import requests
from tqdm import tqdm
from pprint import pprint


def mkdir(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)


def download_file(url, save_path):
    print('download save_path:', save_path)
    with open(save_path, 'wb') as f:
        file = requests.get(url)
        f.write(file.content)

def modify_config(CMakeDownloadLog_txt):
    '''
    line: #cmake_download "E:/software_install/opencv/opencv-4.5.5/.cache/wechat_qrcode/238e2b2d6f3c18d6c3a30de0c31e23cf-detect.caffemodel" "https://raw.githubusercontent.com/WeChatCV/opencv_3rdparty/a8b69ccc738421293254aec5ddb38bd523503252/detect.caffemodel"
    :param CMakeDownloadLog_txt:
    :return:
    '''
    cache_dir = '.cache'
    mkdir(cache_dir)
    lines = [item.strip() for item in open(CMakeDownloadLog_txt)]


    download_url_path_dict = {}
    with open('download_list.md', 'w', encoding='utf-8') as f:
        f.write('下载文件名链接 | 修改后文件名  |  修改后文件存储路径位置\n')
        f.write(':----|:-----|:-----\n')
        for line in tqdm(lines):
            if line.startswith('#cmake_download'):
                cache_path, download_url = line.split()[1:]
                print('cache_path:', cache_path)
                print('download_url:', download_url)
                download_name = os.path.basename(download_url)
                rename_name = os.path.basename(cache_path)
                save_download_file_dir = os.path.join(cache_dir, os.path.basename(os.path.dirname(cache_path)))
                mkdir(save_download_file_dir)
                save_path = os.path.abspath(os.path.join(save_download_file_dir, download_name))
                print('save_path:', save_path)   # save_path: E:\test\modify_config\cache\wechat_qrcode\detect.caffemodel"   需要转义
                add_speed_download_url = 'https://github.91chi.fun/' + download_url
                save_path2 = save_path.replace('\\', '/')
                print('save_path2:', save_path2)  # save_path2: E:/test/modify_config/.cache/wechat_qrcode/detect.caffemodel
                download_file(add_speed_download_url, str(save_path2))  # 下载报错：OSError: [Errno 22] Invalid argument: 'E:/test/modify_config/.cache/wechat_qrcode/detect.caffemodel"'
                # download_file(add_speed_download_url, 'E:/test/modify_config/.cache/wechat_qrcode/detect.caffemodel')  # 可以正常下载


                # save_path3 = save_path2.replace('E', 'e')
                # print('save_path3:', save_path3)  # save_path3: e:/test/modify_config/.cache/wechat_qrcode/detect.caffemodel
                # download_file(add_speed_download_url, save_path3)



                write_line = '[{}]({})| `{}`|`{}`\n'.format(download_name, add_speed_download_url, rename_name, os.path.dirname(cache_path))
                f.write(write_line)



if __name__ == '__main__':
    CMakeDownloadLog_txt = 'E:/software_install/opencv/build/CMakeDownloadLog.txt'
    modify_config(CMakeDownloadLog_txt)